#!/usr/bin/env python3
import os
import sys
import stripe
from flask import Flask, send_from_directory, send_file, request, jsonify
from decimal import Decimal
import uuid
import sendgrid
from sendgrid.helpers.mail import Mail

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "production-secret-key")

# In-memory storage for production deployment
transactions = []

# Initialize Stripe
stripe_key = os.environ.get('STRIPE_SECRET_KEY')
if stripe_key and stripe_key.startswith('sk_'):
    stripe.api_key = stripe_key
    print(f"Stripe configured: {stripe_key[:12]}...")
else:
    print("Warning: Stripe API key not configured")

# Initialize SendGrid
sg_key = os.environ.get('SENDGRID_API_KEY')
if sg_key:
    sg = sendgrid.SendGridAPIClient(api_key=sg_key)
    print("SendGrid configured")
else:
    print("Warning: SendGrid not configured")

# Domain configuration
YOUR_DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN') if os.environ.get('REPLIT_DEPLOYMENT') != '' else os.environ.get('REPLIT_DOMAINS', 'localhost:5000').split(',')[0]

def send_email_notification(to_email, subject, content):
    """Send email notification via SendGrid"""
    try:
        if not sg_key:
            print(f"Email notification skipped - SendGrid not configured")
            return False
            
        message = Mail(
            from_email='noreply@flashcash.app',
            to_emails=to_email,
            subject=subject,
            html_content=content
        )
        
        response = sg.send(message)
        print(f"Email sent to {to_email}: {response.status_code}")
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

@app.route('/')
def serve_react_app():
    """Serve the main React application"""
    if os.path.exists('dist/index.html'):
        return send_file('dist/index.html')
    else:
        return send_file('index.html')

@app.route('/test-payment')
def test_payment_flow():
    """Serve payment flow test page"""
    return send_file('test_payment_flow.html')

@app.route('/<path:path>')
def serve_static_files(path):
    """Serve static files from the dist directory"""
    if os.path.exists(f'dist/{path}'):
        return send_from_directory('dist', path)
    else:
        return serve_react_app()

# API Routes for payment processing
@app.route('/api/create-payment-session', methods=['POST'])
def create_payment_session():
    try:
        if not stripe.api_key:
            return jsonify({
                'error': 'Payment system not configured. Please set STRIPE_SECRET_KEY environment variable.'
            }), 503
        
        data = request.get_json()
        amount = float(data.get('amount', 0))
        recipient_email = data.get('recipient_email', '')
        sender_email = data.get('sender_email', '')
        note = data.get('note', '')
        
        if amount <= 0:
            return jsonify({'error': 'Invalid amount'}), 400
            
        if not recipient_email:
            return jsonify({'error': 'Recipient email required'}), 400
        
        amount_cents = int(amount * 100)
        is_guest = bool(sender_email)
        transaction_description = note if note else 'FlashCash transfer'
        
        if is_guest:
            product_name = f'Guest: Send ${amount:.2f} from {sender_email} to {recipient_email}'
        else:
            product_name = f'Send ${amount:.2f} to {recipient_email}'
        
        transaction_id = str(uuid.uuid4())
        transactions.append({
            'id': transaction_id,
            'amount': amount,
            'recipient_email': recipient_email,
            'sender_email': sender_email,
            'description': transaction_description,
            'status': 'pending',
            'type': 'send'
        })
        
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': product_name,
                        'description': transaction_description
                    },
                    'unit_amount': amount_cents,
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=f'https://{YOUR_DOMAIN}/?payment=success&session_id={{CHECKOUT_SESSION_ID}}',
            cancel_url=f'https://{YOUR_DOMAIN}/?payment=cancelled',
            metadata={
                'amount': str(amount),
                'recipient_email': recipient_email,
                'sender_email': sender_email if is_guest else '',
                'note': note,
                'transaction_id': transaction_id
            }
        )
        
        return jsonify({
            'checkout_url': checkout_session.url,
            'session_id': checkout_session.id
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/request-money', methods=['POST'])
def request_money():
    try:
        data = request.get_json()
        amount = float(data.get('amount', 0))
        from_email = data.get('from_email', '')
        requester_email = data.get('requester_email', '')
        note = data.get('note', '')
        
        if amount <= 0:
            return jsonify({'error': 'Invalid amount'}), 400
        if not from_email:
            return jsonify({'error': 'Recipient email required'}), 400
        if not requester_email:
            return jsonify({'error': 'Your email required'}), 400
        
        request_id = str(uuid.uuid4())
        
        email_content = f"""
        <h2>FlashCash Money Request</h2>
        <p>{requester_email} has requested ${amount:.2f} from you.</p>
        {f'<p><strong>Note:</strong> {note}</p>' if note else ''}
        <p>Click the link below to send the payment:</p>
        <a href="https://{YOUR_DOMAIN}/?pay_request={request_id}" 
           style="background-color: #9AFF00; color: black; padding: 12px 24px; text-decoration: none; border-radius: 8px;">
           Send ${amount:.2f}
        </a>
        """
        
        if send_email_notification(from_email, f"Money Request from {requester_email}", email_content):
            transactions.append({
                'id': request_id,
                'amount': amount,
                'from_email': from_email,
                'requester_email': requester_email,
                'note': note,
                'status': 'requested',
                'type': 'request'
            })
            return jsonify({'message': 'Money request sent successfully'})
        else:
            return jsonify({'error': 'Failed to send money request'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/claim-money', methods=['POST'])
def claim_money():
    try:
        data = request.get_json()
        amount = float(data.get('amount', 0))
        claimant_email = data.get('claimant_email', '')
        note = data.get('note', '')
        
        if amount <= 0:
            return jsonify({'error': 'Invalid amount'}), 400
        if not claimant_email:
            return jsonify({'error': 'Your email required'}), 400
        
        claim_id = str(uuid.uuid4())
        
        email_content = f"""
        <h2>FlashCash Money Claim</h2>
        <p>{claimant_email} is claiming ${amount:.2f}.</p>
        {f'<p><strong>Reason:</strong> {note}</p>' if note else ''}
        <p>This claim has been recorded and will be processed.</p>
        """
        
        admin_email = "crowden071@gmail.com"
        if send_email_notification(admin_email, f"Money Claim from {claimant_email}", email_content):
            transactions.append({
                'id': claim_id,
                'amount': amount,
                'claimant_email': claimant_email,
                'note': note,
                'status': 'claimed',
                'type': 'claim'
            })
            return jsonify({'message': 'Money claim submitted successfully'})
        else:
            return jsonify({'error': 'Failed to submit money claim'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/payment-success')
def payment_success():
    session_id = request.args.get('session_id')
    if session_id:
        try:
            session = stripe.checkout.Session.retrieve(session_id)
            metadata = session.metadata
            
            admin_email = "crowden071@gmail.com"
            email_content = f"""
            <h2>Payment Successful</h2>
            <p>Amount: ${metadata.get('amount')}</p>
            <p>To: {metadata.get('recipient_email')}</p>
            <p>From: {metadata.get('sender_email') or 'Registered User'}</p>
            {f'<p>Note: {metadata.get("note")}</p>' if metadata.get('note') else ''}
            """
            
            send_email_notification(admin_email, "FlashCash Payment Completed", email_content)
            
        except Exception as e:
            print(f"Payment success handling error: {e}")
    
    return serve_react_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)