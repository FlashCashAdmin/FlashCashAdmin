import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, X } from 'lucide-react';

interface GuestSendMoneyProps {
  isOpen: boolean;
  onClose: () => void;
}

const GuestSendMoney: React.FC<GuestSendMoneyProps> = ({ isOpen, onClose }) => {
  const [amount, setAmount] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [note, setNote] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !recipientEmail || !senderEmail) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/create-payment-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: parseFloat(amount),
          recipient_email: recipientEmail,
          sender_email: senderEmail,
          note: note || ''
        }),
      });

      const data = await response.json();
      
      if (response.ok && data.checkout_url) {
        window.location.href = data.checkout_url;
      } else {
        alert(`Payment failed: ${data.error || 'Unknown error'}`);
      }
    } catch (error) {
      alert('Payment failed: Network error');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="glass-card p-6 w-full max-w-md mx-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Send className="w-6 h-6 text-electric-green" />
            Send Money - Guest
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-white/70" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-white/70 text-sm mb-2">Your Email</label>
            <input
              type="email"
              value={senderEmail}
              onChange={(e) => setSenderEmail(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:border-electric-green focus:outline-none"
              placeholder="your@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-white/70 text-sm mb-2">Amount ($)</label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:border-electric-green focus:outline-none"
              placeholder="0.00"
              required
            />
          </div>

          <div>
            <label className="block text-white/70 text-sm mb-2">Send To</label>
            <input
              type="email"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:border-electric-green focus:outline-none"
              placeholder="recipient@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-white/70 text-sm mb-2">Note (Optional)</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:border-electric-green focus:outline-none"
              placeholder="What's this for?"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 p-3 bg-gradient-to-r from-electric-green to-bright-cyan text-black font-medium rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Send Money
                </>
              )}
            </button>
          </div>
        </form>

        <div className="mt-4 p-3 bg-bright-cyan/10 border border-bright-cyan/20 rounded-lg">
          <p className="text-bright-cyan text-sm">
            <strong>Guest Mode:</strong> You can send money without creating an account. 
            The recipient will receive the payment directly.
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default GuestSendMoney;