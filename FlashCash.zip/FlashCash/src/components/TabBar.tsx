
import React from 'react';
import { HomeIcon, WalletIcon, HistoryIcon, ProfileIcon, NeonFilters } from './NeonIcons';

interface Tab {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface TabBarProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  className?: string;
}

const TabBar: React.FC<TabBarProps> = ({ tabs, activeTab, onTabChange, className = '' }) => {
  const getTabIcon = (tabId: string) => {
    switch (tabId) {
      case 'home':
        return <HomeIcon size={20} color={activeTab === tabId ? '#000000' : '#9AFF00'} />;
      case 'summary':
        return <WalletIcon size={20} color={activeTab === tabId ? '#000000' : '#00FFFF'} />;
      case 'history':
        return <HistoryIcon size={20} color={activeTab === tabId ? '#000000' : '#9AFF00'} />;
      case 'profile':
        return <ProfileIcon size={20} color={activeTab === tabId ? '#000000' : '#00FFFF'} />;
      default:
        return null;
    }
  };

  return (
    <>
      <NeonFilters />
      <div className={`fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-xl border-t border-white/10 z-50 ${className}`}>
        <div className="flex justify-around py-1 px-2 max-w-md mx-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center py-1 px-2 rounded-md transition-all min-w-0 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-electric-green to-bright-cyan text-black'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <div className="mb-0.5">
                {getTabIcon(tab.id)}
              </div>
              <span className={`text-xs font-medium truncate ${
                activeTab === tab.id ? 'text-black' : 'text-white/90'
              }`}>
                {tab.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </>
  );
};

export default TabBar;
