import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, DollarSign, Gift, ArrowRight, CheckCircle, XCircle } from 'lucide-react';

interface PaymentFlowDemoProps {
  isOpen: boolean;
  onClose: () => void;
}

const PaymentFlowDemo: React.FC<PaymentFlowDemoProps> = ({ isOpen, onClose }) => {
  const [currentFlow, setCurrentFlow] = useState<'guest' | 'send' | 'request' | 'claim' | null>(null);
  const [currentStep, setCurrentStep] = useState(0);

  const flows = {
    guest: {
      title: 'Guest Send Money',
      icon: <Send className="w-6 h-6" />,
      color: 'electric-green',
      steps: [
        { title: 'Landing Page', description: 'Click "Send Money as Guest" button', status: 'active' },
        { title: 'Guest Form', description: 'Fill: Your email, Amount, Recipient, Optional note', status: 'pending' },
        { title: 'Stripe Checkout', description: 'Secure payment processing with card details', status: 'pending' },
        { title: 'Payment Complete', description: 'Success redirect with confirmation', status: 'pending' }
      ]
    },
    send: {
      title: 'Authenticated Send Money',
      icon: <DollarSign className="w-6 h-6" />,
      color: 'bright-cyan',
      steps: [
        { title: 'Dashboard Login', description: 'User authenticated and on dashboard', status: 'active' },
        { title: 'Send Modal', description: 'Click Send button, fill Amount, Recipient, Optional note', status: 'pending' },
        { title: 'Stripe Processing', description: 'Create payment session and redirect to checkout', status: 'pending' },
        { title: 'Transaction Recorded', description: 'Payment success, notification created, history updated', status: 'pending' }
      ]
    },
    request: {
      title: 'Request Money',
      icon: <ArrowRight className="w-6 h-6" />,
      color: 'electric-green',
      steps: [
        { title: 'Dashboard Request', description: 'Click Request button on authenticated dashboard', status: 'active' },
        { title: 'Request Form', description: 'Fill Amount, From email, Optional description', status: 'pending' },
        { title: 'Create Request', description: 'Generate pending transaction record', status: 'pending' },
        { title: 'Notification Sent', description: 'Add to activity feed and notify recipient', status: 'pending' }
      ]
    },
    claim: {
      title: 'Claim Money',
      icon: <Gift className="w-6 h-6" />,
      color: 'bright-cyan',
      steps: [
        { title: 'Dashboard Claim', description: 'Click Claim button for cashback/rewards', status: 'active' },
        { title: 'Claim Form', description: 'Fill Amount and Source for claim', status: 'pending' },
        { title: 'Process Claim', description: 'Create approved transaction immediately', status: 'pending' },
        { title: 'Success Notification', description: 'Update balance and transaction history', status: 'pending' }
      ]
    }
  };

  const handleStepProgress = () => {
    if (currentFlow && currentStep < flows[currentFlow].steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const resetDemo = () => {
    setCurrentFlow(null);
    setCurrentStep(0);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Payment Flow Demonstrations</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <XCircle className="w-6 h-6 text-white/70" />
          </button>
        </div>

        {!currentFlow ? (
          <div className="grid md:grid-cols-2 gap-6">
            {Object.entries(flows).map(([key, flow]) => (
              <motion.button
                key={key}
                onClick={() => setCurrentFlow(key as any)}
                className={`p-6 bg-white/5 border border-${flow.color}/20 rounded-lg hover:bg-${flow.color}/10 transition-all text-left group`}
                whileHover={{ scale: 1.02 }}
              >
                <div className={`flex items-center gap-3 mb-4 text-${flow.color}`}>
                  {flow.icon}
                  <h3 className="text-xl font-semibold text-white">{flow.title}</h3>
                </div>
                <p className="text-white/70 mb-4">
                  {flow.steps.length} step process demonstrating the complete user journey
                </p>
                <div className="flex items-center gap-2 text-white/50 group-hover:text-white/70">
                  <span>View Flow</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </motion.button>
            ))}
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-6">
              <button
                onClick={resetDemo}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <ArrowRight className="w-5 h-5 text-white/70 rotate-180" />
              </button>
              <div className={`text-${flows[currentFlow].color} flex items-center gap-2`}>
                {flows[currentFlow].icon}
                <h3 className="text-xl font-semibold text-white">{flows[currentFlow].title}</h3>
              </div>
            </div>

            <div className="space-y-4">
              {flows[currentFlow].steps.map((step, index) => (
                <motion.div
                  key={index}
                  className={`p-4 rounded-lg border transition-all ${
                    index === currentStep
                      ? `border-${flows[currentFlow].color} bg-${flows[currentFlow].color}/10`
                      : index < currentStep
                      ? 'border-electric-green bg-electric-green/5'
                      : 'border-white/10 bg-white/5'
                  }`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      index === currentStep
                        ? `bg-${flows[currentFlow].color} text-black`
                        : index < currentStep
                        ? 'bg-electric-green text-black'
                        : 'bg-white/10 text-white/50'
                    }`}>
                      {index < currentStep ? (
                        <CheckCircle className="w-5 h-5" />
                      ) : (
                        <span className="font-semibold">{index + 1}</span>
                      )}
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">{step.title}</h4>
                      <p className="text-white/70 text-sm">{step.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="flex justify-between items-center mt-6 pt-4 border-t border-white/10">
              <div className="text-white/50 text-sm">
                Step {currentStep + 1} of {flows[currentFlow].steps.length}
              </div>
              <div className="flex gap-3">
                <button
                  onClick={resetDemo}
                  className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                >
                  Reset
                </button>
                {currentStep < flows[currentFlow].steps.length - 1 && (
                  <button
                    onClick={handleStepProgress}
                    className={`px-4 py-2 bg-gradient-to-r from-${flows[currentFlow].color} to-bright-cyan text-black font-medium rounded-lg hover:opacity-90 transition-opacity`}
                  >
                    Next Step
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 p-4 bg-white/5 border border-white/10 rounded-lg">
          <h4 className="font-semibold text-white mb-2">Key Features:</h4>
          <ul className="text-white/70 text-sm space-y-1">
            <li>• Guest mode requires no account creation</li>
            <li>• All note fields are optional to reduce friction</li>
            <li>• Stripe handles secure payment processing</li>
            <li>• Real-time notifications for authenticated users</li>
            <li>• Transaction history tracking in Activity tab</li>
          </ul>
        </div>
      </motion.div>
    </div>
  );
};

export default PaymentFlowDemo;