

interface IconProps {
  size?: number;
  className?: string;
  color?: string;
}

export const HomeIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M3 12L12 3L21 12M5 10V20A1 1 0 006 21H9M19 10V20A1 1 0 0118 21H15M9 21V16A1 1 0 0110 15H14A1 1 0 0115 16V21M9 21H15" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const WalletIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M19 7H5C3.89543 7 3 7.89543 3 9V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 19 20.1046 19 19V9C19 7.89543 20.1046 7 19 7Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M16 3H8C6.89543 3 6 3.89543 6 5V7H18V5C18 3.89543 17.1046 3 16 3Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <circle cx="15" cy="13" r="2" stroke={color} strokeWidth="2" filter="url(#neonGlow)" />
  </svg>
);

export const HistoryIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M3 12A9 9 0 1021 12A9 9 0 003 12Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M12 7V12L15 15" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const SendIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M22 2L11 13" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M22 2L15 22L11 13L2 9L22 2Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const RequestIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M9 12L15 6M15 6H11M15 6V10" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M15 18L9 12M9 12H13M9 12V16" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <circle 
      cx="12" 
      cy="12" 
      r="10" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const ClaimIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const NotificationIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M18 8A6 6 0 006 8C6 15 3 17 3 17H21S18 15 18 8Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M13.73 21A2 2 0 0110.27 21" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const ProfileIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle 
      cx="12" 
      cy="12" 
      r="10" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <circle 
      cx="12" 
      cy="8" 
      r="3" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M8.21 13.89A7 7 0 0015.79 13.89" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const ChartIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M3 3V21H21" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M9 9L12 6L16 10L21 5" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <circle cx="9" cy="9" r="1" fill={color} filter="url(#neonGlow)" />
    <circle cx="12" cy="6" r="1" fill={color} filter="url(#neonGlow)" />
    <circle cx="16" cy="10" r="1" fill={color} filter="url(#neonGlow)" />
    <circle cx="21" cy="5" r="1" fill={color} filter="url(#neonGlow)" />
  </svg>
);

export const SearchIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle 
      cx="11" 
      cy="11" 
      r="8" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
    <path 
      d="M21 21L16.65 16.65" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

export const FilterIcon = ({ size = 24, className = '', color = 'currentColor' }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path 
      d="M22 3H2L10 12.46V19L14 21V12.46L22 3Z" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      filter="url(#neonGlow)"
    />
  </svg>
);

// SVG Filters for neon glow effect
export const NeonFilters = () => (
  <svg width="0" height="0" style={{ position: 'absolute' }}>
    <defs>
      <filter id="neonGlow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
        <feMerge> 
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
  </svg>
);