import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, Smartphone, Send, CreditCard, Play } from 'lucide-react';
import GuestSendMoney from '../components/GuestSendMoney';
import PaymentFlowDemo from '../components/PaymentFlowDemo';

interface LandingPageProps {
  onLogin: () => void;
  onRegister: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLogin, onRegister }) => {
  const [showGuestSend, setShowGuestSend] = useState(false);
  const [showFlowDemo, setShowFlowDemo] = useState(false);
  
  const features = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Instant Transfers",
      description: "Send and receive money in seconds with our lightning-fast platform"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Secure & Safe",
      description: "Bank-level security with end-to-end encryption for all transactions"
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "Mobile First",
      description: "Optimized for mobile with a sleek, intuitive interface"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8"
          >
            {/* Brand Logo */}
            <div className="mb-8">
              <motion.div
                className="w-24 h-24 bg-primary-gradient rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl"
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Zap className="w-12 h-12 text-black" />
              </motion.div>
              <h1 className="text-6xl md:text-7xl font-bold text-gradient mb-4">
                FlashCash
              </h1>
              <p className="text-xl md:text-2xl text-white/80 mb-8">
                Lightning-fast money transfers at your fingertips
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <motion.button
                onClick={onLogin}
                className="btn-gradient flex items-center justify-center gap-2 px-8 py-4 text-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Send className="w-5 h-5" />
                Sign In
              </motion.button>
              <motion.button
                onClick={onRegister}
                className="bg-transparent border-2 border-bright-cyan text-bright-cyan hover:bg-secondary-gradient hover:text-black font-semibold px-8 py-4 rounded-2xl flex items-center justify-center gap-2 text-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <CreditCard className="w-5 h-5" />
                Get Started
              </motion.button>
            </div>
            
            {/* Guest Send Money Option */}
            <div className="mb-8">
              <motion.button
                onClick={() => setShowGuestSend(true)}
                className="bg-white/10 border border-electric-green text-electric-green hover:bg-electric-green hover:text-black font-medium px-6 py-3 rounded-lg flex items-center justify-center gap-2 mx-auto transition-all duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Zap className="w-4 h-4" />
                Send Money as Guest
              </motion.button>
              <p className="text-white/50 text-sm text-center mt-2">
                No account required - send money instantly
              </p>
            </div>

            {/* Payment Flow Demo Button */}
            <div className="mb-12">
              <motion.button
                onClick={() => setShowFlowDemo(true)}
                className="bg-white/5 border border-bright-cyan/50 text-bright-cyan hover:bg-bright-cyan/10 font-medium px-4 py-2 rounded-lg flex items-center justify-center gap-2 mx-auto transition-all duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Play className="w-4 h-4" />
                View Payment Flows
              </motion.button>
            </div>
          </motion.div>

          {/* Features Grid */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto"
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="glass-card p-8 text-center hover:scale-105"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <div className="w-16 h-16 bg-secondary-gradient rounded-full flex items-center justify-center mx-auto mb-6 text-black">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-4 text-white">
                  {feature.title}
                </h3>
                <p className="text-white/70 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </motion.div>

          {/* Demo Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-16 grid grid-cols-3 gap-8 max-w-2xl mx-auto"
          >
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient mb-2">$2.4M+</div>
              <div className="text-white/60 text-sm">Transferred</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient mb-2">50K+</div>
              <div className="text-white/60 text-sm">Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient mb-2">99.9%</div>
              <div className="text-white/60 text-sm">Uptime</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center py-8 text-white/50 text-sm border-t border-white/10">
        <p>&copy; 2024 FlashCash. Built for instant transfers.</p>
      </footer>
      
      {/* Guest Send Money Modal */}
      <GuestSendMoney 
        isOpen={showGuestSend} 
        onClose={() => setShowGuestSend(false)} 
      />
      
      {/* Payment Flow Demo Modal */}
      <PaymentFlowDemo 
        isOpen={showFlowDemo} 
        onClose={() => setShowFlowDemo(false)} 
      />
    </div>
  );
};

export default LandingPage;