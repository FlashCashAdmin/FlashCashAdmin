import React, { useState, useEffect } from 'react';
import { User } from '../types';
import TabBar from '../components/TabBar';
import { NotificationIcon, ProfileIcon, SendIcon, RequestIcon, ClaimIcon, SearchIcon, FilterIcon } from '../components/NeonIcons';

interface Transaction {
  id: string;
  description: string;
  amount: number;
  status: 'pending' | 'paid' | 'cancelled' | 'declined' | 'approved';
  date: string;
  recipient?: string;
  type: 'sent' | 'received' | 'request' | 'claim';
}

interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
}

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showSendMoney, setShowSendMoney] = useState(false);
  const [showRequestMoney, setShowRequestMoney] = useState(false);
  const [showClaimMoney, setShowClaimMoney] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sendAmount, setSendAmount] = useState('');
  const [sendRecipient, setSendRecipient] = useState('');
  const [sendDescription, setSendDescription] = useState('');

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));

      const mockTransactions: Transaction[] = [
        {
          id: '1',
          description: 'Coffee at Starbucks',
          amount: -5.50,
          status: 'paid',
          date: new Date().toISOString(),
          recipient: 'Starbucks',
          type: 'sent'
        },
        {
          id: '2',
          description: 'Payment from John',
          amount: 25.00,
          status: 'approved',
          date: new Date(Date.now() - 86400000).toISOString(),
          recipient: 'John Doe',
          type: 'received'
        },
        {
          id: '3',
          description: 'Uber ride payment',
          amount: -12.30,
          status: 'pending',
          date: new Date(Date.now() - 172800000).toISOString(),
          recipient: 'Uber',
          type: 'sent'
        },
        {
          id: '4',
          description: 'Money request to Sarah',
          amount: 50.00,
          status: 'pending',
          date: new Date(Date.now() - 259200000).toISOString(),
          recipient: 'Sarah Wilson',
          type: 'request'
        },
        {
          id: '5',
          description: 'Cashback claim',
          amount: 15.75,
          status: 'approved',
          date: new Date(Date.now() - 345600000).toISOString(),
          recipient: 'FlashCash Rewards',
          type: 'claim'
        },
        {
          id: '6',
          description: 'Declined payment attempt',
          amount: -100.00,
          status: 'declined',
          date: new Date(Date.now() - 432000000).toISOString(),
          recipient: 'Online Store',
          type: 'sent'
        }
      ];

      const mockNotifications: Notification[] = [
        {
          id: '1',
          message: 'Payment received from John Doe',
          type: 'success',
          timestamp: new Date().toISOString(),
          read: false
        },
        {
          id: '2',
          message: 'Your payment to Uber is pending',
          type: 'warning',
          timestamp: new Date(Date.now() - 86400000).toISOString(),
          read: false
        },
        {
          id: '3',
          message: 'Monthly salary has been credited',
          type: 'success',
          timestamp: new Date(Date.now() - 259200000).toISOString(),
          read: true
        }
      ];

      setTransactions(mockTransactions);
      setNotifications(mockNotifications);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setTransactions([]);
      setNotifications([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMoney = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sendAmount || !sendRecipient) return;

    try {
      const response = await fetch('/api/create-payment-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: parseFloat(sendAmount),
          recipient_email: sendRecipient,
          note: sendDescription || '' // Optional field
        }),
      });

      const data = await response.json();
      
      if (response.ok && data.checkout_url) {
        // Redirect to Stripe checkout
        window.location.href = data.checkout_url;
      } else {
        const notification: Notification = {
          id: Date.now().toString(),
          message: `Payment failed: ${data.error || 'Unknown error'}`,
          type: 'error',
          timestamp: new Date().toISOString(),
          read: false
        };
        setNotifications(prev => [notification, ...prev]);
      }
    } catch (error) {
      const notification: Notification = {
        id: Date.now().toString(),
        message: 'Payment failed: Network error',
        type: 'error',
        timestamp: new Date().toISOString(),
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    }
  };

  const handleRequestMoney = async (amount: string, from: string, description?: string) => {
    try {
      const response = await fetch('/api/request-money', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: parseFloat(amount),
          from_email: from,
          requester_email: user.email,
          description: description || ''
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Add to local state for immediate UI update
        const newTransaction: Transaction = {
          id: data.transaction_id,
          description: description || `Request from ${from}`,
          amount: parseFloat(amount),
          status: 'pending',
          date: new Date().toISOString(),
          recipient: from,
          type: 'request'
        };

        setTransactions(prev => [newTransaction, ...prev]);

        const notification: Notification = {
          id: Date.now().toString(),
          message: data.message,
          type: 'success',
          timestamp: new Date().toISOString(),
          read: false
        };
        setNotifications(prev => [notification, ...prev]);
      } else {
        const notification: Notification = {
          id: Date.now().toString(),
          message: data.error || 'Failed to send money request',
          type: 'error',
          timestamp: new Date().toISOString(),
          read: false
        };
        setNotifications(prev => [notification, ...prev]);
      }
    } catch (error) {
      const notification: Notification = {
        id: Date.now().toString(),
        message: 'Network error while sending request',
        type: 'error',
        timestamp: new Date().toISOString(),
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    }
  };

  const handleClaimMoney = async (amount: string, source: string) => {
    try {
      const response = await fetch('/api/claim-money', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: parseFloat(amount),
          source: source,
          claimer_email: user.email
        }),
      });

      const data = await response.json();

      if (response.ok) {
        const newTransaction: Transaction = {
          id: data.transaction_id,
          description: `Cashback claim from ${source}`,
          amount: parseFloat(amount),
          status: 'paid', // Claims are instantly completed
          date: new Date().toISOString(),
          recipient: source,
          type: 'claim'
        };

        setTransactions(prev => [newTransaction, ...prev]);

        const notification: Notification = {
          id: Date.now().toString(),
          message: data.message,
          type: 'success',
          timestamp: new Date().toISOString(),
          read: false
        };
        setNotifications(prev => [notification, ...prev]);
      } else {
        const notification: Notification = {
          id: Date.now().toString(),
          message: data.error || 'Failed to claim money',
          type: 'error',
          timestamp: new Date().toISOString(),
          read: false
        };
        setNotifications(prev => [notification, ...prev]);
      }
    } catch (error) {
      const notification: Notification = {
        id: Date.now().toString(),
        message: 'Network error while claiming money',
        type: 'error',
        timestamp: new Date().toISOString(),
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-electric-green/20 text-electric-green';
      case 'approved': return 'bg-electric-green/20 text-electric-green';
      case 'pending': return 'bg-white/20 text-white';
      case 'cancelled': return 'bg-white/10 text-white/70';
      case 'declined': return 'bg-white/10 text-white/70';
      default: return 'bg-bright-cyan/20 text-bright-cyan';
    }
  };

  const formatAmount = (amount: number) => {
    const sign = amount >= 0 ? '+' : '';
    return `${sign}$${Math.abs(amount).toFixed(2)}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };



  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.recipient?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || transaction.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const unreadNotifications = notifications.filter(n => !n.read);
  const claimableNotifications = notifications.filter(n => 
    n.type === 'success' && 
    n.message.toLowerCase().includes('received') && 
    !n.read
  );

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-app-gradient">
        <div className="glass-card p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-electric-green mx-auto"></div>
          <p className="text-center mt-4 text-white/70">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const renderHomeTab = () => (
    <div className="flex-1 overflow-y-auto p-3 pb-16">
      {/* Brand Header - Upper Left */}
      <div className="mb-4 pt-2 pl-2">
        <h1 className="text-2xl font-bold text-white mb-1">FlashCash</h1>
        <p className="text-white/70 text-sm">Welcome back, {user.username}</p>
      </div>

      {/* Balance Card */}
      <div className="glass-card p-4 mb-4">
        <h2 className="text-base font-semibold text-white mb-1">Current Balance</h2>
        <p className="text-3xl font-bold text-white mb-3">$1,247.83</p>

        {/* Pending Notifications */}
        {unreadNotifications.length > 0 && (
          <div className="mb-4 p-3 bg-white/10 border border-white/20 rounded-lg">
            <p className="text-white text-sm font-medium">
              {unreadNotifications.length} pending notification{unreadNotifications.length > 1 ? 's' : ''}
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className={`grid gap-3 ${claimableNotifications.length > 0 ? 'grid-cols-3' : 'grid-cols-2'}`}>
          <button
            onClick={() => setShowSendMoney(true)}
            className="flex flex-col items-center p-4 bg-white/10 border border-white/20 rounded-lg hover:bg-white/20 transition-all"
          >
            <SendIcon size={24} color="#9AFF00" />
            <span className="text-white text-sm font-medium mt-2">Send</span>
          </button>

          <button
            onClick={() => setShowRequestMoney(true)}
            className="flex flex-col items-center p-4 bg-white/10 border border-white/20 rounded-lg hover:bg-white/20 transition-all"
          >
            <RequestIcon size={24} color="#9AFF00" />
            <span className="text-white text-sm font-medium mt-2">Request</span>
          </button>

          {claimableNotifications.length > 0 && (
            <button
              onClick={() => setShowClaimMoney(true)}
              className="flex flex-col items-center p-4 bg-white/10 border border-white/20 rounded-lg hover:bg-white/20 transition-all relative"
            >
              <ClaimIcon size={24} color="#9AFF00" />
              <span className="text-white text-sm font-medium mt-2">Claim</span>
              {claimableNotifications.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-electric-green text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {claimableNotifications.length}
                </span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="glass-card p-4">
        <h3 className="text-lg font-semibold text-white mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {transactions.slice(0, 5).map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  transaction.type === 'sent' ? 'bg-white/10' :
                  transaction.type === 'received' ? 'bg-electric-green/20' :
                  transaction.type === 'request' ? 'bg-bright-cyan/20' :
                  'bg-white/10'
                }`}>
                  {transaction.type === 'sent' ? <SendIcon size={16} color="#9AFF00" /> :
                   transaction.type === 'received' ? <SendIcon size={16} color="#00FFFF" /> :
                   transaction.type === 'request' ? <RequestIcon size={16} color="#00FFFF" /> :
                   <ClaimIcon size={16} color="#9AFF00" />}
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{transaction.description}</p>
                  <p className="text-white/60 text-xs">{transaction.recipient}</p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-sm font-bold ${transaction.amount >= 0 ? 'text-electric-green' : 'text-bright-cyan'}`}>
                  {formatAmount(transaction.amount)}
                </p>
                <p className={`text-xs px-2 py-1 rounded ${getStatusColor(transaction.status)}`}>
                  {transaction.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderProfileTab = () => (
    <div className="flex-1 overflow-y-auto p-3 pb-16">
      {/* Tab Header */}
      <div className="text-center mb-4 pt-2">
        <h1 className="text-xl font-bold text-white mb-1">Profile</h1>
        <p className="text-white/70 text-sm">Manage your account settings</p>
      </div>

      {/* Profile Info */}
      <div className="glass-card p-4 mb-4">
        <div className="flex items-center mb-4">
          <div className="w-16 h-16 bg-electric-green/20 rounded-full flex items-center justify-center mr-3">
            <ProfileIcon size={24} color="#9AFF00" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">{user.username}</h2>
            <p className="text-white/70 text-sm">{user.email}</p>
          </div>
        </div>

        {/* Profile Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="stat-card border-l-electric-green">
            <div className="text-white/70 text-sm">Member Since</div>
            <div className="text-lg font-bold text-white">Jan 2024</div>
          </div>
          <div className="stat-card border-l-bright-cyan">
            <div className="text-white/70 text-sm">Total Transactions</div>
            <div className="text-lg font-bold text-white">{transactions.length}</div>
          </div>
        </div>
      </div>

      {/* Account Settings */}
      <div className="glass-card p-6 mb-6">
        <h3 className="text-lg font-semibold text-white mb-4">Account Settings</h3>
        <div className="space-y-4">
          <button 
            onClick={() => {
              const notification: Notification = {
                id: Date.now().toString(),
                message: 'Personal information settings coming soon!',
                type: 'info',
                timestamp: new Date().toISOString(),
                read: false
              };
              setNotifications(prev => [notification, ...prev]);
            }}
            className="w-full p-3 bg-white/10 rounded-lg text-left text-white hover:bg-white/20 transition-colors"
          >
            <div className="font-medium">Personal Information</div>
            <div className="text-sm text-white/70">Update your profile details</div>
          </button>

          <button 
            onClick={() => {
              const notification: Notification = {
                id: Date.now().toString(),
                message: 'Security settings panel coming soon!',
                type: 'info',
                timestamp: new Date().toISOString(),
                read: false
              };
              setNotifications(prev => [notification, ...prev]);
            }}
            className="w-full p-3 bg-white/10 rounded-lg text-left text-white hover:bg-white/20 transition-colors"
          >
            <div className="font-medium">Security Settings</div>
            <div className="text-sm text-white/70">Change password and 2FA</div>
          </button>

          <button 
            onClick={() => {
              const notification: Notification = {
                id: Date.now().toString(),
                message: 'Payment methods management coming soon!',
                type: 'info',
                timestamp: new Date().toISOString(),
                read: false
              };
              setNotifications(prev => [notification, ...prev]);
            }}
            className="w-full p-3 bg-white/10 rounded-lg text-left text-white hover:bg-white/20 transition-colors"
          >
            <div className="font-medium">Payment Methods</div>
            <div className="text-sm text-white/70">Manage linked accounts</div>
          </button>

          <button 
            onClick={() => {
              const notification: Notification = {
                id: Date.now().toString(),
                message: 'Notification preferences updated successfully!',
                type: 'success',
                timestamp: new Date().toISOString(),
                read: false
              };
              setNotifications(prev => [notification, ...prev]);
            }}
            className="w-full p-3 bg-white/10 rounded-lg text-left text-white hover:bg-white/20 transition-colors"
          >
            <div className="font-medium">Notification Preferences</div>
            <div className="text-sm text-white/70">Email and push notification</div>
          </button>
        </div>
      </div>

      {/* Account Actions */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Account Actions</h3>
        <div className="space-y-3">
          <button 
            onClick={() => {
              const csvData = transactions.map(t => 
                `${t.date},${t.description},${t.amount},${t.status},${t.type}`
              ).join('\n');
              const blob = new Blob([`Date,Description,Amount,Status,Type\n${csvData}`], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'flashcash-transactions.csv';
              a.click();
              URL.revokeObjectURL(url);

              const notification: Notification = {
                id: Date.now().toString(),
                message: 'Transaction history exported successfully!',
                type: 'success',
                timestamp: new Date().toISOString(),
                read: false
              };
              setNotifications(prev => [notification, ...prev]);
            }}
            className="w-full p-3 bg-electric-green/20 border border-electric-green/30 rounded-lg text-electric-green hover:bg-electric-green/30 transition-colors"
          >
            Export Transaction History
          </button>

          <button 
            onClick={() => {
              const notification: Notification = {
                id: Date.now().toString(),
                message: 'Support ticket created! We\'ll get back to you within 24 hours.',
                type: 'success',
                timestamp: new Date().toISOString(),
                read: false
              };
              setNotifications(prev => [notification, ...prev]);
            }}
            className="w-full p-3 bg-bright-cyan/20 border border-bright-cyan/30 rounded-lg text-bright-cyan hover:bg-bright-cyan/30 transition-colors"
          >
            Contact Support
          </button>

          <button 
            onClick={onLogout}
            className="w-full p-3 bg-white/10 border border-white/30 rounded-lg text-white hover:bg-white/20 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );

  const renderHistoryTab = () => (
    <div className="flex-1 overflow-y-auto p-4 pb-20">
      {/* Search and Filter */}
      <div className="glass-card p-4 mb-4">
        <div className="flex space-x-3 mb-3">
          <div className="flex-1 relative">
            <SearchIcon size={16} color="#9AFF00" className="absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-electric-green"
            />
          </div>
          <button className="p-2 bg-white/10 border border-white/20 rounded-lg hover:bg-white/20 transition-colors">
            <FilterIcon size={16} color="#00FFFF" />
          </button>
        </div>

        <div className="flex space-x-2 overflow-x-auto">
          {['all', 'pending', 'paid', 'declined', 'approved'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all whitespace-nowrap ${
                filterStatus === status
                  ? 'bg-electric-green text-black'
                  : 'bg-white/10 text-white/70 hover:bg-white/20'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Transaction List */}
      <div className="glass-card p-4">
        <h3 className="text-lg font-semibold text-white mb-4">Transaction History</h3>
        <div className="space-y-3">
          {filteredTransactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white/10">
                  {transaction.type === 'sent' ? <SendIcon size={18} color="#9AFF00" /> :
                   transaction.type === 'received' ? <SendIcon size={18} color="#00FFFF" /> :
                   transaction.type === 'request' ? <RequestIcon size={18} color="#9AFF00" /> :
                   <ClaimIcon size={18} color="#00FFFF" />}
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{transaction.description}</p>
                  <p className="text-white/60 text-xs">{transaction.recipient}</p>
                  <p className="text-white/40 text-xs">{formatDate(transaction.date)}</p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-sm font-bold ${transaction.amount >= 0 ? 'text-electric-green' : 'text-bright-cyan'}`}>
                  {formatAmount(transaction.amount)}
                </p>
                <p className={`text-xs px-2 py-1 rounded ${getStatusColor(transaction.status)}`}>
                  {transaction.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-app-gradient relative">
      {/* Top Icons - Only Notifications on Home Page */}
      {activeTab === 'home' && (
        <div className="absolute top-6 right-6 flex items-center space-x-3 z-40">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <NotificationIcon size={20} color="#FFFFFF" />
            {unreadNotifications.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-electric-green text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {unreadNotifications.length}
              </span>
            )}
          </button>
        </div>
      )}

      {/* Notification Panel */}
      {showNotifications && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-card p-6 w-full max-w-lg max-h-[85vh] overflow-hidden flex flex-col mx-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">Notifications</h2>
              <button
                onClick={() => setShowNotifications(false)}
                className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
              >
                ✕
              </button>
            </div>

            {notifications.length > 0 ? (
              <div className="flex-1 overflow-y-auto space-y-3">
                {notifications.map((notification) => (
                  <div 
                    key={notification.id} 
                    className={`p-3 rounded-lg border ${
                      !notification.read 
                        ? 'bg-white/10 border-electric-green/30' 
                        : 'bg-white/5 border-white/10'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className={`text-sm ${
                          notification.type === 'success' ? 'text-electric-green' :
                          notification.type === 'warning' ? 'text-white' :
                          notification.type === 'error' ? 'text-white/70' :
                          'text-bright-cyan'
                        }`}>
                          {notification.message}
                        </p>
                        <p className="text-white/50 text-xs mt-1">
                          {formatDate(notification.timestamp)}
                        </p>
                      </div>
                      {!notification.read && (
                        <button
                          onClick={() => {
                            setNotifications(prev => prev.map(n => 
                              n.id === notification.id ? { ...n, read: true } : n
                            ));
                          }}
                          className="ml-2 px-2 py-1 bg-electric-green/20 text-electric-green text-xs rounded hover:bg-electric-green/30 transition-colors"
                        >
                          Mark Read
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-white/70">No notifications yet</p>
              </div>
            )}

            {notifications.some(n => !n.read) && (
              <div className="mt-4 pt-4 border-t border-white/10">
                <button
                  onClick={() => {
                    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
                  }}
                  className="w-full p-2 bg-electric-green/20 text-electric-green rounded-lg hover:bg-electric-green/30 transition-colors"
                >
                  Mark All as Read
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Profile Panel */}
      {showProfile && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-card p-6 w-full max-w-sm max-h-[80vh] overflow-hidden flex flex-col mx-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">Profile</h2>
              <button
                onClick={() => setShowProfile(false)}
                className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-electric-green rounded-full mx-auto mb-3 flex items-center justify-center">
                  <span className="text-black font-bold text-xl">{user.username.charAt(0).toUpperCase()}</span>
                </div>
                <h3 className="text-white font-semibold">{user.username}</h3>
                <p className="text-white/70 text-sm">{user.email}</p>
              </div>

              <div className="space-y-3">
                <button className="w-full p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors text-left">
                  Account Settings
                </button>
                <button className="w-full p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors text-left">
                  Security
                </button>
                <button className="w-full p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors text-left">
                  Payment Methods
                </button>
                <button className="w-full p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors text-left">
                  Help
                </button>
                <button 
                  onClick={onLogout}
                  className="w-full p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors text-left"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      {activeTab === 'home' && renderHomeTab()}
      {activeTab === 'history' && renderHistoryTab()}
      {activeTab === 'profile' && renderProfileTab()}

      {/* Send Money Modal */}
      {showSendMoney && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto mx-auto">
            <h2 className="text-xl font-bold text-white mb-4">Send Money</h2>
            <form onSubmit={handleSendMoney} className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm mb-2">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={sendAmount}
                  onChange={(e) => setSendAmount(e.target.value)}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-2">To</label>
                <input
                  type="text"
                  value={sendRecipient}
                  onChange={(e) => setSendRecipient(e.target.value)}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  placeholder="Recipient name or email"
                  required
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-2">Note (Optional)</label>
                <input
                  type="text"
                  value={sendDescription}
                  onChange={(e) => setSendDescription(e.target.value)}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  placeholder="What's this for?"
                />
              </div>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setShowSendMoney(false)}
                  className="flex-1 p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 p-3 bg-gradient-to-r from-electric-green to-bright-cyan text-black font-medium rounded-lg hover:opacity-90 transition-opacity"
                >
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Request Money Modal */}
      {showRequestMoney && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto mx-auto">
            <h2 className="text-xl font-bold text-white mb-4">Request Money</h2>
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.target as HTMLFormElement);
              handleRequestMoney(
                formData.get('amount') as string,
                formData.get('from') as string,
                formData.get('description') as string
              );
              setShowRequestMoney(false);
            }} className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm mb-2">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  name="amount"
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-2">From</label>
                <input
                  type="text"
                  name="from"
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  placeholder="Who to request from"
                  required
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-2">Description</label>
                <input
                  type="text"
                  name="description"
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  placeholder="What's this for?"
                  required
                />
              </div>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setShowRequestMoney(false)}
                  className="flex-1 p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 p-3 bg-gradient-to-r from-bright-cyan to-electric-green text-black font-medium rounded-lg hover:opacity-90 transition-opacity"
                >
                  Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Claim Money Modal */}
      {showClaimMoney && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto mx-auto">
            <h2 className="text-xl font-bold text-white mb-4">Claim Received Payments</h2>

            {claimableNotifications.length > 0 ? (
              <div className="space-y-4">
                <p className="text-white/70 text-sm mb-4">
                  You have {claimableNotifications.length} received payment{claimableNotifications.length > 1 ? 's' : ''} ready to claim:
                </p>

                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {claimableNotifications.map((notification) => (
                    <div key={notification.id} className="bg-white/10 rounded-lg p-3 border border-green-500/30">
                      <p className="text-white text-sm">{notification.message}</p>
                      <p className="text-white/50 text-xs mt-1">{formatDate(notification.timestamp)}</p>
                      <button
                        onClick={() => {
                          // Extract amount from notification message
                          const amountMatch = notification.message.match(/\$(\d+\.?\d*)/);
                          const amount = amountMatch ? amountMatch[1] : '0';
                          const sender = notification.message.split(' from ')[1] || 'Unknown';

                          handleClaimMoney(amount, sender);

                          // Mark notification as read
                          setNotifications(prev => prev.map(n => 
                            n.id === notification.id ? { ...n, read: true } : n
                          ));

                          setShowClaimMoney(false);
                        }}
                        className="mt-2 w-full p-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-sm font-medium rounded-lg hover:opacity-90 transition-opacity"
                      >
                        Claim This Payment
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex space-x-3 mt-4">
                  <button
                    type="button"
                    onClick={() => setShowClaimMoney(false)}
                    className="flex-1 p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      // Claim all payments
                      claimableNotifications.forEach(notification => {
                        const amountMatch = notification.message.match(/\$(\d+\.?\d*)/);
                        const amount = amountMatch ? amountMatch[1] : '0';
                        const sender = notification.message.split(' from ')[1] || 'Unknown';
                        handleClaimMoney(amount, sender);
                      });

                      // Mark all as read
                      setNotifications(prev => prev.map(n => 
                        claimableNotifications.find(cn => cn.id === n.id) ? { ...n, read: true } : n
                      ));

                      setShowClaimMoney(false);
                    }}
                    className="flex-1 p-3 bg-gradient-to-r from-electric-green to-bright-cyan text-black font-medium rounded-lg hover:opacity-90 transition-opacity"
                  >
                    Claim All
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-white/70 mb-4">No received payments to claim at this time.</p>
                <button
                  onClick={() => setShowClaimMoney(false)}
                  className="p-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab Bar */}
      <TabBar
        tabs={[
          { id: 'home', label: 'Home' },
          { id: 'history', label: 'Activity' },
          { id: 'profile', label: 'Profile' }
        ]}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
    </div>
  );
};

export default Dashboard;