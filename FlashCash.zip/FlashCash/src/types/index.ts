
export interface User {
  id: string;
  username: string;
  email: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface Transaction {
  id: string;
  description: string;
  amount: number;
  status: 'pending' | 'paid' | 'cancelled' | 'declined' | 'approved';
  date: string;
  recipient?: string;
  type: 'sent' | 'received' | 'request' | 'claim';
}

export interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
}
