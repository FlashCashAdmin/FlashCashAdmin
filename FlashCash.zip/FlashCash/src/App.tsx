import React, { useState, useEffect } from 'react';
import { AuthState } from './types';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';
import { authService } from './utils/authService';

type Page = 'landing' | 'login' | 'register' | 'dashboard';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true
  });

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const user = await authService.getCurrentUser();
      if (user) {
        setAuthState({
          user,
          isAuthenticated: true,
          isLoading: false
        });
        setCurrentPage('dashboard');
      } else {
        setAuthState({
          user: null,
          isAuthenticated: false,
          isLoading: false
        });
      }
    } catch (error) {
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false
      });
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const user = await authService.login(email, password);
      setAuthState({
        user,
        isAuthenticated: true,
        isLoading: false
      });
      setCurrentPage('dashboard');
    } catch (error) {
      throw error;
    }
  };

  const handleRegister = async (username: string, email: string, password: string) => {
    try {
      await authService.register(username, email, password);
      setCurrentPage('login');
    } catch (error) {
      throw error;
    }
  };

  const handleLogout = async () => {
    try {
      await authService.logout();
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false
      });
      setCurrentPage('landing');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (authState.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass-card p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-electric-green mx-auto"></div>
          <p className="text-center mt-4 text-white/70">Loading...</p>
        </div>
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return (
          <LandingPage
            onLogin={() => setCurrentPage('login')}
            onRegister={() => setCurrentPage('register')}
          />
        );
      case 'login':
        return (
          <LoginPage
            onLogin={handleLogin}
            onRegister={() => setCurrentPage('register')}
            onBack={() => setCurrentPage('landing')}
          />
        );
      case 'register':
        return (
          <RegisterPage
            onRegister={handleRegister}
            onLogin={() => setCurrentPage('login')}
            onBack={() => setCurrentPage('landing')}
          />
        );
      case 'dashboard':
        return (
          <Dashboard
            user={authState.user!}
            onLogout={handleLogout}
          />
        );
      default:
        return (
          <LandingPage
            onLogin={() => setCurrentPage('login')}
            onRegister={() => setCurrentPage('register')}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-main-bg">
      {renderPage()}
    </div>
  );
}

export default App;