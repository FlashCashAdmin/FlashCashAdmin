
import { User } from '../types';

class AuthService {
  private currentUser: User | null = null;

  async login(email: string, password: string): Promise<User> {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Login failed');
      }

      const user = await response.json();
      this.currentUser = user;
      localStorage.setItem('flashcash_user', JSON.stringify(user));
      return user;
    } catch (error) {
      throw new Error(error instanceof Error ? error.message : 'Network error occurred');
    }
  }

  async register(username: string, email: string, password: string): Promise<void> {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, email, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Registration failed');
      }
    } catch (error) {
      throw new Error(error instanceof Error ? error.message : 'Network error occurred');
    }
  }

  async logout(): Promise<void> {
    this.currentUser = null;
    localStorage.removeItem('flashcash_user');
  }

  async getCurrentUser(): Promise<User | null> {
    if (this.currentUser) {
      return this.currentUser;
    }

    const savedUser = localStorage.getItem('flashcash_user');
    if (savedUser) {
      try {
        this.currentUser = JSON.parse(savedUser);
        return this.currentUser;
      } catch (error) {
        localStorage.removeItem('flashcash_user');
      }
    }

    return null;
  }
}

export const authService = new AuthService();
