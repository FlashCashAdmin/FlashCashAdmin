
import { User } from '../types';

class AuthService {
  private currentUser: User | null = null;

  async login(email: string, password: string): Promise<User> {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Demo credentials check
    if (email === 'demo@flashcash.app' && password === 'demo123') {
      const user: User = {
        id: '1',
        username: 'demo_user',
        email: 'demo@flashcash.app'
      };
      this.currentUser = user;
      localStorage.setItem('flashcash_user', JSON.stringify(user));
      return user;
    }

    throw new Error('Invalid credentials');
  }

  async register(username: string, email: string, password: string): Promise<void> {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Basic validation
    if (!username || !email || !password) {
      throw new Error('All fields are required');
    }

    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters');
    }

    // Simulate successful registration
    console.log('User registered:', { username, email });
  }

  async logout(): Promise<void> {
    this.currentUser = null;
    localStorage.removeItem('flashcash_user');
  }

  async getCurrentUser(): Promise<User | null> {
    if (this.currentUser) {
      return this.currentUser;
    }

    const savedUser = localStorage.getItem('flashcash_user');
    if (savedUser) {
      try {
        this.currentUser = JSON.parse(savedUser);
        return this.currentUser;
      } catch (error) {
        localStorage.removeItem('flashcash_user');
      }
    }

    return null;
  }
}

export const authService = new AuthService();
